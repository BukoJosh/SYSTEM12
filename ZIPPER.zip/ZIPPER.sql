/*
SQLyog Job Agent v12.09 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 10.4.32-MariaDB : Database - gradesystem
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`gradesystem` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `gradesystem`;

/*Table structure for table `finalsgrades` */

DROP TABLE IF EXISTS `finalsgrades`;

CREATE TABLE `finalsgrades` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `Name` varchar(100) NOT NULL,
  `CourseYear` varchar(50) NOT NULL,
  `Calculus` decimal(5,2) DEFAULT NULL,
  `Physics` decimal(5,2) DEFAULT NULL,
  `Chemistry` decimal(5,2) DEFAULT NULL,
  `Fundamental` decimal(5,2) DEFAULT NULL,
  `Database` decimal(5,2) DEFAULT NULL,
  `PE` decimal(5,2) DEFAULT NULL,
  `NSTP` decimal(5,2) DEFAULT NULL,
  `FinalGrade` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserID` (`UserID`),
  CONSTRAINT `finalsgrades_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `finalsgrades` */

insert  into `finalsgrades` values (2,NULL,'FART','BSCE 3rd Year',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Incomplete');

/*Table structure for table `grades` */

DROP TABLE IF EXISTS `grades`;

CREATE TABLE `grades` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `Name` varchar(100) NOT NULL,
  `CourseYear` varchar(50) NOT NULL,
  `Calculus` decimal(5,2) DEFAULT NULL,
  `Physics` decimal(5,2) DEFAULT NULL,
  `Chemistry` decimal(5,2) DEFAULT NULL,
  `Fundamental` decimal(5,2) DEFAULT NULL,
  `Database` decimal(5,2) DEFAULT NULL,
  `PE` decimal(5,2) DEFAULT NULL,
  `NSTP` decimal(5,2) DEFAULT NULL,
  `FinalGrade` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserID` (`UserID`),
  CONSTRAINT `grades_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `grades` */

insert  into `grades` values (2,NULL,'FART','BSCE 3rd Year',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Incomplete');

/*Table structure for table `midtermgrades` */

DROP TABLE IF EXISTS `midtermgrades`;

CREATE TABLE `midtermgrades` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `Name` varchar(100) NOT NULL,
  `CourseYear` varchar(50) NOT NULL,
  `Calculus` decimal(5,2) DEFAULT NULL,
  `Physics` decimal(5,2) DEFAULT NULL,
  `Chemistry` decimal(5,2) DEFAULT NULL,
  `Fundamental` decimal(5,2) DEFAULT NULL,
  `Database` decimal(5,2) DEFAULT NULL,
  `PE` decimal(5,2) DEFAULT NULL,
  `NSTP` decimal(5,2) DEFAULT NULL,
  `FinalGrade` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserID` (`UserID`),
  CONSTRAINT `midtermgrades_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `midtermgrades` */

insert  into `midtermgrades` values (2,NULL,'FART','BSCE 3rd Year',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Incomplete');

/*Table structure for table `prelimgrades` */

DROP TABLE IF EXISTS `prelimgrades`;

CREATE TABLE `prelimgrades` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `Name` varchar(100) NOT NULL,
  `CourseYear` varchar(50) NOT NULL,
  `Calculus` decimal(5,2) DEFAULT NULL,
  `Physics` decimal(5,2) DEFAULT NULL,
  `Chemistry` decimal(5,2) DEFAULT NULL,
  `Fundamental` decimal(5,2) DEFAULT NULL,
  `Database` decimal(5,2) DEFAULT NULL,
  `PE` decimal(5,2) DEFAULT NULL,
  `NSTP` decimal(5,2) DEFAULT NULL,
  `FinalGrade` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserID` (`UserID`),
  CONSTRAINT `prelimgrades_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `prelimgrades` */

insert  into `prelimgrades` values (2,NULL,'FART','BSCE 3rd Year','90.00','89.00','87.00','90.00','86.00','90.00','90.00','88.85714285714286');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(50) NOT NULL,
  `PasswordHash` varchar(255) NOT NULL,
  `Position` varchar(50) NOT NULL,
  PRIMARY KEY (`UserID`),
  UNIQUE KEY `Username` (`Username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `users` */

insert  into `users` values (1,'MR SUAVE','hello1234','Management');

/* Trigger structure for table `finalsgrades` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `check_missing_subjects_finals` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `check_missing_subjects_finals` BEFORE INSERT ON `finalsgrades` FOR EACH ROW BEGIN
    -- Check if any subject grade is NULL
    IF NEW.Calculus IS NULL OR NEW.Physics IS NULL OR NEW.Chemistry IS NULL 
       OR NEW.Fundamental IS NULL OR NEW.Database IS NULL OR NEW.PE IS NULL 
       OR NEW.NSTP IS NULL THEN
        SET NEW.FinalGrade = 'Incomplete'; -- Mark as "Incomplete" if any subject is missing
    ELSE
        -- Calculate FinalGrade if all subjects are present
        SET NEW.FinalGrade = (NEW.Calculus + NEW.Physics + NEW.Chemistry + 
                              NEW.Fundamental + NEW.Database + NEW.PE + NEW.NSTP) / 7;
    END IF;
END */$$


DELIMITER ;

/* Trigger structure for table `grades` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `check_missing_subjects_insert` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `check_missing_subjects_insert` BEFORE INSERT ON `grades` FOR EACH ROW BEGIN
    IF NEW.Calculus IS NULL OR NEW.Physics IS NULL OR NEW.Chemistry IS NULL 
       OR NEW.Fundamental IS NULL OR NEW.Database IS NULL OR NEW.PE IS NULL 
       OR NEW.NSTP IS NULL THEN
        SET NEW.FinalGrade = 'Incomplete';
    ELSE
        SET NEW.FinalGrade = (NEW.Calculus + NEW.Physics + NEW.Chemistry + 
                              NEW.Fundamental + NEW.Database + NEW.PE + NEW.NSTP) / 7;
    END IF;
END */$$


DELIMITER ;

/* Trigger structure for table `grades` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `insert_name_course_midterm` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `insert_name_course_midterm` AFTER INSERT ON `grades` FOR EACH ROW BEGIN
    INSERT INTO MidtermGrades (UserID, Name, CourseYear)
    VALUES (NEW.UserID, NEW.Name, NEW.CourseYear);
END */$$


DELIMITER ;

/* Trigger structure for table `grades` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `insert_name_course_finals` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `insert_name_course_finals` AFTER INSERT ON `grades` FOR EACH ROW BEGIN
    INSERT INTO FinalsGrades (UserID, Name, CourseYear)
    VALUES (NEW.UserID, NEW.Name, NEW.CourseYear);
END */$$


DELIMITER ;

/* Trigger structure for table `grades` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `insert_name_course_prelim` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `insert_name_course_prelim` AFTER INSERT ON `grades` FOR EACH ROW BEGIN
    INSERT INTO PrelimGrades (UserID, Name, CourseYear)
    VALUES (NEW.UserID, NEW.Name, NEW.CourseYear);
END */$$


DELIMITER ;

/* Trigger structure for table `grades` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `check_and_stack` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `check_and_stack` AFTER INSERT ON `grades` FOR EACH ROW BEGIN
    -- Check and insert into PrelimGrades if not exists
    IF NOT EXISTS (
        SELECT 1 FROM PrelimGrades 
        WHERE Name = NEW.Name AND CourseYear = NEW.CourseYear
    ) THEN
        INSERT INTO PrelimGrades (Name, CourseYear) 
        VALUES (NEW.Name, NEW.CourseYear);
    END IF;
    -- Check and insert into MidtermGrades if not exists
    IF NOT EXISTS (
        SELECT 1 FROM MidtermGrades 
        WHERE Name = NEW.Name AND CourseYear = NEW.CourseYear
    ) THEN
        INSERT INTO MidtermGrades (Name, CourseYear) 
        VALUES (NEW.Name, NEW.CourseYear);
    END IF;
    -- Check and insert into FinalsGrades if not exists
    IF NOT EXISTS (
        SELECT 1 FROM FinalsGrades 
        WHERE Name = NEW.Name AND CourseYear = NEW.CourseYear
    ) THEN
        INSERT INTO FinalsGrades (Name, CourseYear) 
        VALUES (NEW.Name, NEW.CourseYear);
    END IF;
END */$$


DELIMITER ;

/* Trigger structure for table `grades` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `check_missing_subjects_update` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `check_missing_subjects_update` BEFORE UPDATE ON `grades` FOR EACH ROW BEGIN
    IF NEW.Calculus IS NULL OR NEW.Physics IS NULL OR NEW.Chemistry IS NULL 
       OR NEW.Fundamental IS NULL OR NEW.Database IS NULL OR NEW.PE IS NULL 
       OR NEW.NSTP IS NULL THEN
        SET NEW.FinalGrade = 'Incomplete';
    ELSE
        SET NEW.FinalGrade = (NEW.Calculus + NEW.Physics + NEW.Chemistry + 
                              NEW.Fundamental + NEW.Database + NEW.PE + NEW.NSTP) / 7;
    END IF;
END */$$


DELIMITER ;

/* Trigger structure for table `grades` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `delete_name_course_prelim` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `delete_name_course_prelim` AFTER DELETE ON `grades` FOR EACH ROW BEGIN
    DELETE FROM PrelimGrades
    WHERE Name = OLD.Name;
END */$$


DELIMITER ;

/* Trigger structure for table `grades` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `delete_name_course_midterm` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `delete_name_course_midterm` AFTER DELETE ON `grades` FOR EACH ROW BEGIN
    DELETE FROM MidtermGrades
    WHERE Name = OLD.Name;
END */$$


DELIMITER ;

/* Trigger structure for table `grades` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `delete_name_course_finals` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `delete_name_course_finals` AFTER DELETE ON `grades` FOR EACH ROW BEGIN
    DELETE FROM FinalsGrades
    WHERE Name = OLD.Name;
END */$$


DELIMITER ;

/* Trigger structure for table `midtermgrades` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `check_missing_subjects_midterm` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `check_missing_subjects_midterm` BEFORE INSERT ON `midtermgrades` FOR EACH ROW BEGIN
    -- Check if any subject grade is NULL
    IF NEW.Calculus IS NULL OR NEW.Physics IS NULL OR NEW.Chemistry IS NULL 
       OR NEW.Fundamental IS NULL OR NEW.Database IS NULL OR NEW.PE IS NULL 
       OR NEW.NSTP IS NULL THEN
        SET NEW.FinalGrade = 'Incomplete'; -- Mark as "Incomplete" if any subject is missing
    ELSE
        -- Calculate FinalGrade if all subjects are present
        SET NEW.FinalGrade = (NEW.Calculus + NEW.Physics + NEW.Chemistry + 
                              NEW.Fundamental + NEW.Database + NEW.PE + NEW.NSTP) / 7;
    END IF;
END */$$


DELIMITER ;

/* Trigger structure for table `prelimgrades` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `check_missing_subjects_prelim` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `check_missing_subjects_prelim` BEFORE INSERT ON `prelimgrades` FOR EACH ROW BEGIN
    -- Check if any subject grade is NULL
    IF NEW.Calculus IS NULL OR NEW.Physics IS NULL OR NEW.Chemistry IS NULL 
       OR NEW.Fundamental IS NULL OR NEW.Database IS NULL OR NEW.PE IS NULL 
       OR NEW.NSTP IS NULL THEN
        SET NEW.FinalGrade = 'Incomplete'; -- Mark as "Incomplete" if any subject is missing
    ELSE
        -- Calculate FinalGrade if all subjects are present
        SET NEW.FinalGrade = (NEW.Calculus + NEW.Physics + NEW.Chemistry + 
                              NEW.Fundamental + NEW.Database + NEW.PE + NEW.NSTP) / 7;
    END IF;
END */$$


DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
